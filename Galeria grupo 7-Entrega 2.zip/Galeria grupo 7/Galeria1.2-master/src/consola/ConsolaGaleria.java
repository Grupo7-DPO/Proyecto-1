package consola;

import java.io.IOException;

import modelo.Galeria;


public class ConsolaGaleria {


}
