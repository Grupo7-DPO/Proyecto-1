package modelo;

import java.util.ArrayList;

import modelo.inventario.Piezas;
import modelo.usuarios.Cliente;


public class Galeria {
	private ArrayList<Cliente> mapaClientes;
	private ArrayList<Piezas> mapaPiezas;
}
