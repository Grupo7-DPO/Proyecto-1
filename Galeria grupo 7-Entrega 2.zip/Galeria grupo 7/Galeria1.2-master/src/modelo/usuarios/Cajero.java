package modelo.usuarios;

public class Cajero extends Usuarios{
	
	public void recibirPago() {
		
	}
}
