package modelo.usuarios;

public class Propietario extends Usuarios{

}
